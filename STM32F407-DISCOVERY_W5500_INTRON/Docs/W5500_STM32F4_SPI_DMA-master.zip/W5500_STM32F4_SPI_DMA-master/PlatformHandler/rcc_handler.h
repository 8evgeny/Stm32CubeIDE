#ifndef _RCC_HANDLER_H_
#define _RCC_HANDLER_H_

void RCC_Configuration(void);

#endif
