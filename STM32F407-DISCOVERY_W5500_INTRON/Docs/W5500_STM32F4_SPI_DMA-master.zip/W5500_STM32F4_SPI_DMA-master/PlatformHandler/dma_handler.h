#ifndef _DMA_HANDLER_H_
#define _DMA_HANDLER_H_

#define SPI1_DR_ADDRESS          0x4001300C

void DMA_Configuration(void);

#endif
