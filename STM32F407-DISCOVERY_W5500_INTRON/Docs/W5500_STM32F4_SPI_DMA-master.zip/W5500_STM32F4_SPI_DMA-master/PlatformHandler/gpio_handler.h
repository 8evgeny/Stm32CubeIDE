#ifndef _GPIO_HANDLER_H_
#define _GPIO_HANDLER_H_

void GPIO_Configuration(void);

#endif
