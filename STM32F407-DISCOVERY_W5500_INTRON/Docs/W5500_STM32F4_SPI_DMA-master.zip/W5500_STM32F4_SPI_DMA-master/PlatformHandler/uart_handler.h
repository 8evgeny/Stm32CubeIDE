#ifndef _UART_HANDLER_H_
#define _UART_HANDLER_H_

void USART_Configuration(void);

#endif
