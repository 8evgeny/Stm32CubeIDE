#ifndef __COMMON_H_
#define __COMMON_H_

#define DATA_BUF_SIZE   1024

#endif
